/* ============================================
   main.js
   Dos comportamientos: el menú móvil y un único
   momento de animación (los números del hero
   suben al entrar en pantalla). Si tu grupo suma
   JS nuevo, hacelo en una función aparte.
   ============================================ */

document.addEventListener("DOMContentLoaded", () => {
  initMobileNav();
  initStatsReveal();
});

function initMobileNav() {
  const nav = document.querySelector(".nav");
  const toggle = document.querySelector(".nav__toggle");
  if (!nav || !toggle) return;

  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  nav.querySelectorAll(".nav__links a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function initStatsReveal() {
  const stats = document.querySelectorAll("[data-count-to]");
  if (!stats.length) return;

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    stats.forEach((el) => (el.textContent = el.dataset.countTo));
    return;
  }

  const animate = (el) => {
    const target = parseInt(el.dataset.countTo, 10);
    const suffix = el.dataset.suffix || "";
    const duration = 900;
    const start = performance.now();

    function step(now) {
      const progress = Math.min((now - start) / duration, 1);
      const value = Math.round(target * progress);
      el.textContent = value + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  };

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animate(entry.target);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.6 }
  );

  stats.forEach((el) => observer.observe(el));
}
